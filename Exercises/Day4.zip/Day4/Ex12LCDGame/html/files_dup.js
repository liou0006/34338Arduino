var files_dup =
[
    [ "Ex12LCDGame.ino", "_ex12_l_c_d_game_8ino.html", "_ex12_l_c_d_game_8ino" ]
];