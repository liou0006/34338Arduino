var _ex14_animals_8ino =
[
    [ "Animal", "struct_animal.html", "struct_animal" ],
    [ "loop", "_ex14_animals_8ino.html#afe461d27b9c48d5921c00d521181f12f", null ],
    [ "printAnimal", "_ex14_animals_8ino.html#a736fb30f22ce5a6da4b28f7002772c41", null ],
    [ "setup", "_ex14_animals_8ino.html#a4fc01d736fe50cf5b977f755b675f11d", null ],
    [ "swapWeight", "_ex14_animals_8ino.html#aaffd956870eae8c0b804edefa55213c5", null ]
];