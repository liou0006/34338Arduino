var searchData=
[
  ['name_0',['name',['../struct_animal.html#a3c403dfc6a1ab389a400a897fcff7737',1,'Animal']]]
];
