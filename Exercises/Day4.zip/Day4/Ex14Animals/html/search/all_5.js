var searchData=
[
  ['poc_0',['PoC',['../struct_animal.html#a2efb74f662a1775223a2e4f0e5ccbd62',1,'Animal']]],
  ['printanimal_1',['printAnimal',['../_ex14_animals_8ino.html#a736fb30f22ce5a6da4b28f7002772c41',1,'Ex14Animals.ino']]]
];
