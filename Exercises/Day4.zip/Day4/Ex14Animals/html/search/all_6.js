var searchData=
[
  ['setup_0',['setup',['../_ex14_animals_8ino.html#a4fc01d736fe50cf5b977f755b675f11d',1,'Ex14Animals.ino']]],
  ['swapweight_1',['swapWeight',['../_ex14_animals_8ino.html#aaffd956870eae8c0b804edefa55213c5',1,'Ex14Animals.ino']]]
];
