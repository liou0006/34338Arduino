var searchData=
[
  ['alive_0',['alive',['../struct_animal.html#a38d08d48cf5b16863bb40fa731b06629',1,'Animal']]]
];
