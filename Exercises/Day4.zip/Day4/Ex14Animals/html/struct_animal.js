var struct_animal =
[
    [ "alive", "struct_animal.html#a38d08d48cf5b16863bb40fa731b06629", null ],
    [ "family", "struct_animal.html#a2bc355e2503f608b8fa78040c44b8974", null ],
    [ "name", "struct_animal.html#a3c403dfc6a1ab389a400a897fcff7737", null ],
    [ "PoC", "struct_animal.html#a2efb74f662a1775223a2e4f0e5ccbd62", null ],
    [ "weight", "struct_animal.html#a055c4df7dacb89eb4c2ca9bbee11ff24", null ]
];